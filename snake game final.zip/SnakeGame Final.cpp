#include <iostream>
#include <windows.h>
using namespace std;

// initialising my variables 
bool normalGame, mainMenu, snakeGame = true;
const int width = 25;
const int height = 25;

// user variables
int x, y, spd = 1;
int tailX[100], tailY[100], tailLength;

// positioning tail
int fposX, fposY, sposX, sposY;

//target variables
int targetX, targetY;

//game variables
int score; 
enum directions { STOP = 0, UP, DOWN, LEFT, RIGHT };
directions dir;

void game_Over() {
	normalGame = false;
	mainMenu = true;
	tailLength = 0;
	score = 0;
}

void game_Setup() {
	snakeGame = true;
	mainMenu = true;

void main_Menu() {
	system("cls");
	cout << "This is the main menu" << endl;
	cout << "Press Enter to Start the Game" << endl;
	cout << "Whilst the Game is Playing" << endl;
	cout << "Press Enter to End Game" << endl;


	if (GetAsyncKeyState(VK_RETURN)) {
		mainMenu = false;
	}
	else if (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A')) {
			dir = STOP;
	}
	else if (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D')) {
			dir = STOP;
	}
	else if (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S')) {
			dir = STOP;
	}
	else if (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W')) {
			dir = STOP;
	}
}

void normal_Setup() {

	normalGame = true;

	dir = STOP;

	// setting player & target
	x = rand() % width;
	y = rand() % height;
	targetX = rand() % width;
	targetY = rand() % height;

	// errors
	while (x == targetX && y == targetY) {
		x = rand() % width;
		y = rand() % height;
		targetX = rand() % width;
		targetY = rand() % height;
	}
	score = 0;
}

void game_Window() {                           

	system("cls");
	
	for (int i = 0; i < width; i++) {                                // top border
		cout << "*";
	}
	cout << endl;

	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {                            // middle border
			if (j == 0 || j == width - 1) {
				cout << "*";
			}
			else if (i ==y && j == x) {                              // creating snake
				cout << "S";
			}
			else if (i == targetY && j == targetX) {                  // creating target
				cout << "O";
			}
			else {
				bool print = false;                                   // Adding small s to make tail
				for (int k = 0; k < tailLength; k++) {
					if (tailX[k] == j && tailY[k] == i) {
						cout << "s";
						print = true;
					}
				}
				if (!print) {
					cout << " ";
				}
			}
		}
		cout << endl;
	}

	for (int i = 0; i < width; i++) {                                 //bottom border  		
		cout << "*";
	}
	cout << endl;

	//scores
	cout << "Score:" << score;
}

void game_Input() {
	if (mainMenu == false && normalGame == true) {
		if (GetAsyncKeyState(VK_LEFT) || GetAsyncKeyState('A') && dir != RIGHT) {
			dir = LEFT;
		}
		else if (GetAsyncKeyState(VK_RIGHT) || GetAsyncKeyState('D') && dir != LEFT) {
			dir = RIGHT;
		}
		else if (GetAsyncKeyState(VK_DOWN) || GetAsyncKeyState('S') && dir != UP) {
			dir = DOWN;
		}
		else if (GetAsyncKeyState(VK_UP) || GetAsyncKeyState('W') && dir != DOWN) {
			dir = UP;
		}
		else if (GetAsyncKeyState(VK_RETURN)) {
			return;
		}
	}
}


void game_Program() {

	//Tail 
	fposX = tailX[0];
	fposY = tailY[0];
	tailX[0] = x;
	tailY[0] = y;

	for (int i = 1; i < tailLength; i++) {
		sposX = tailX[i];
		sposY = tailY[i];
		tailX[i] = fposX;
		tailY[i] = fposY;
		fposX = sposX;
		fposY = sposY;
	}

	// snakes movement
	switch (dir) {
	case LEFT:
		x -= spd;
		break;
	case UP:
		y -= spd;
		break;
	case RIGHT:
		x += spd;
		break;
	case DOWN:
		y += spd;
		break;
	}

	// if the snake hits the edge
	if (x <= 0 || x >= width - 1 || y < 0 || y > height - 1) {
		game_Over();
	}

	// snake hits tail 
	for (int i = 0; i < tailLength; i++) {
		if (tailX[i] == x && tailY[i] == y) {
			game_Over();
		}
	}

	//hit target 
	if (x == targetX && y == targetY) {
		targetX = rand() % width;
		targetY = rand() % height;
		score += 10;
		tailLength++;
	}
}

int main() {
	
	//bool played = PlaySound("game_music.wav", NULL, SND_ASYNC);   music
	//cout << ""

	game_Setup();
	while (snakeGame == true) {
		if (mainMenu == true) {
			main_Menu();
		}
		else if (mainMenu == false) {
			normal_Setup();
			while (normalGame == true) {
			game_Window();
			game_Input();
			game_Program();
			Sleep(25);
			}
		}
	}
}